# TODO: main bot implementation
